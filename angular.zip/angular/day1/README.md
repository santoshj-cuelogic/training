# angular-skeleton
Modular skeleton app for Angular


## Getting Started

1. Make sure you have `bower` and `node` installed.
2. Clone this repoistory via git clone
3. Once cloned, ````cd angular-skeleton```` and do a ````sudo npm install````
4. Once everything installs, do ````npm start````, this will do a ````bower install```` and start the server on ````localhost:8000````
